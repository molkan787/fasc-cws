<?php 
$_['tweet_text'] = 'Twitter share';
$_['text_your_coupon'] = 'Your social coupon code: <strong>%s</strong>';
$_['text_sale'] = 'Sale';
$_['text_quickview'] = 'Quickview';
$_['text_quickview_product'] = 'Quick View Product';
$_['text_bought'] = 'bought';
?>