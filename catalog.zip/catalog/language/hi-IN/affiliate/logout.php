<?php

// Heading

$_['heading_title'] ='Déconnexion du compte';


// Text

$_['text_message']  ='  <p> Vous avez déconnecté votre compte d`affilié. </p> ';
$_['text_account']  ='Compte';
$_['text_logout']   ='Connectez - Out';