<?php

// Heading

$_['heading_title']        ='Mon compte d`affilié';


// Text

$_['text_account']         ='Compte';
$_['text_my_account']      ='Mon compte d`affilié';
$_['text_my_tracking']     ='Mes informations de suivi';
$_['text_my_transactions'] ='Mes transactions';
$_['text_edit']            ='Modifier les informations de votre compte';
$_['text_password']        ='changez votre mot de passe';
$_['text_payment']         ='Modifiez vos préférences de paiement';
$_['text_tracking']        ='Code personnalisé de suivi des affiliés';
$_['text_transaction']     ='Afficher l`historique de votre transaction';