<?php

// Heading

$_['heading_title'] ='La page que vous recherchez n`a pu être trouvée!';


// Text

$_['text_error']    ='La page que vous recherchez n`a pu être trouvée.';