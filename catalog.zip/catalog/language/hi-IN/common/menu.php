<?php
// Text
$_['text_all'] = 'Montrer tout';