<?php

// Text

$_['text_items']     ='%s élément (s) - %s';
$_['text_empty']     ='Votre panier est vide!';
$_['text_cart']      ='Voir le panier';
$_['text_checkout']  ='कखगघङ';
$_['text_recurring'] ='Profil de paiement';