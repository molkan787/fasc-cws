<?php

// Heading

$_['heading_title'] ='Choisissez une boutique';


// Text

$_['text_default']  ='Défaut';
$_['text_store']    ='Choisissez le magasin que vous souhaitez visiter.';