<?php

// Text

$_['text_total_shipping']		='livraison';
$_['text_total_discount']		='Remise';
$_['text_total_tax']			='Impôt';
$_['text_total_sub']			='Total';
$_['text_total']				='Total';
$_['text_smp_id']				='Agent de vente:';
$_['text_buyer']				='Nom d`utilisateur de l`acheteur:';