<?php

// Text

$_['text_paid_amazon'] 			='Payé sur Amazon USA';
$_['text_total_shipping'] 		='livraison';
$_['text_total_shipping_tax'] 	='Taxe d`expédition';
$_['text_total_giftwrap'] 		='Papier cadeau';
$_['text_total_giftwrap_tax'] 	='Taxe d`emballage cadeau';
$_['text_total_sub'] 			='Total';
$_['text_tax'] 					='Impôt';
$_['text_total'] 				='Total';