<?php

// Text

$_['text_title'] ='Carte de crédit / débit / Paypal / Portefeuille (G2APay)';