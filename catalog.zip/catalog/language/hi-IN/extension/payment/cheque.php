<?php

// Text

$_['text_title']				='Check / Money Order';
$_['text_instruction']			='Check / Money Order Instructions';
$_['text_payable']				='Payer vers:';
$_['text_address']				='Envoyer à:';
$_['text_payment']				='Votre commande ne sera envoyée qu`après réception du paiement.';