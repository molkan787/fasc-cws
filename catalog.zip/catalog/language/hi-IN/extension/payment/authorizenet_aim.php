<?php

// Text

$_['text_title']		   ='Carte de crédit / carte de débit (Autoriser. Net). ';
$_['text_credit_card']     ='Détails de la carte de crédit';


// Entry

$_['entry_cc_owner']       ='Propriétaire de la carte';
$_['entry_cc_number']      ='Numéro de carte';
$_['entry_cc_expire_date'] ='date d`expiration de la carte';
$_['entry_cc_cvv2']		   ='Code de sécurité de la carte (CVV2)';