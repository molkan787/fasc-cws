<?php

// Heading

$_['heading_title']				   ='Klarna Checkout';
$_['heading_title_success']		   ='Votre commande Klarna Checkout a été placée!';


// Text

$_['text_title']				   ='Klarna Checkout';
$_['text_basket']				   ='Chariot';
$_['text_checkout']				   ='Check-out';
$_['text_success']				   ='Succès';
$_['text_choose_shipping_method']  ='Choisissez la méthode d`expédition';
$_['text_sales_tax']			   ='Taxe de vente';