<?php

// Text

$_['text_title'] ='Carte de crédit / carte de débit (Autoriser. Net). ';