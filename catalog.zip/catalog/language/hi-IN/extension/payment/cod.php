<?php

// Text

$_['text_title'] ='Paiement à la livraison';