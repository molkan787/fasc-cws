<?php

// Text

$_['text_title']				='Carte de crédit / débit (Paymate)';
$_['text_unable']				='Impossible de localiser ou de mettre à jour le statut de votre commande';
$_['text_declined']				='Le paiement a été refusé par Paymate';
$_['text_failed']				='Échec de la transaction Paymate';
$_['text_failed_message']		='  <p> Malheureusement, une erreur s`est produite lors de la transformation de votre transaction Paymate. </p>  <p>  <b> Attention: </b> %s </p>  <p> Vérifiez votre solde du compte Paymate avant d`essayer de ré-traiter cette commande </p>  <p> Si vous pensez que cette transaction s`est bien déroulée ou si vous présentez une déduction dans votre compte Paymate, s`il vous plaît <a href="%s"> Contactez nous </a> Avec les détails de votre commande. </p> ';
$_['text_basket']				='Panier';
$_['text_checkout']				='Check-out';
$_['text_success']				='Succès';