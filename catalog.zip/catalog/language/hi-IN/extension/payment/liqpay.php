<?php

// Text

$_['text_title'] ='Carte de crédit / débit (LiqPay)';