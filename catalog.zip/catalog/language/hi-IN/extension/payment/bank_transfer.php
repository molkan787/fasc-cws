<?php

// Text

$_['text_title']				='Virement';
$_['text_instruction']			='Instructions de virement bancaire';
$_['text_description']			='Veuillez transférer le montant total au compte bancaire suivant.';
$_['text_payment']				='Votre commande ne sera envoyée qu`après réception du paiement.';