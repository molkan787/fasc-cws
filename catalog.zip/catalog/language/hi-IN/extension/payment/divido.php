<?php

$_['text_checkout_title']      ='Paiement par versements';
$_['text_choose_plan']         ='Choisissez votre plan';
$_['text_choose_deposit']      ='Choisissez votre dépôt';
$_['text_monthly_payments']    ='Paiements mensuels de';
$_['text_months']              ='mois';
$_['text_term']                ='Terme';
$_['text_deposit']             ='Dépôt';
$_['text_credit_amount']       ='Coût du crédit';
$_['text_amount_payable']      ='Total à payer';
$_['text_total_interest']      ='APR d`intérêt total';
$_['text_monthly_installment'] ='Acompte mensuel';
$_['text_redirection']         ='Vous serez redirigé vers Divido pour compléter cette demande de financement lorsque vous confirmez votre commande';
$_['divido_checkout']          ='Confirmer et cocher avec Divido';
$_['deposit_to_low']           ='Déposer à bas';
$_['credit_amount_to_low']     ='Le montant du crédit est faible';
$_['no_country']               ='Pays non accepté';
