<?php

$_['heading_title'] = 'Square Credit Cards';

$_['text_account'] = 'Compte';
$_['text_back'] = 'Retour';
$_['text_delete'] = 'Supprimez';
$_['text_no_cards'] = 'Il n`y a pas de cartes stock�es dans notre base de donn�es.';
$_['text_card_ends_in'] = '%s carte se terminant par &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card'] = 'Confirmez-vous que vous voulez retirer cette carte? Vous pouvez l`ajouter plus tard lors de votre prochaine commande.';
$_['text_success_card_delete'] = 'Succ�s! Cette carte a �t� supprim�e.';