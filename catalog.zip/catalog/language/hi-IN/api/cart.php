<?php

// Text

$_['text_success']     ='Succès: Vous avez modifié votre panier!';


// Error

$_['error_permission'] ='Avertissement: Vous n`avez pas la permission d`accéder à l`API!';
$_['error_stock']      ='Les produits marqués avec *** ne sont pas disponibles en quantité désirée ou pas en stock!';
$_['error_minimum']    ='Le montant minimum de la commande pour %s est de %s!';
$_['error_store']      ='Le produit ne peut pas être acheté dans le magasin que vous avez choisi!';
$_['error_required']   ='%s requis!';