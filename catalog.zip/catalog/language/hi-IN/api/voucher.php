<?php

// Text

$_['text_success']     ='Succès: votre réduction de bon cadeau a été appliquée!';
$_['text_cart']        ='Succès: Vous avez modifié votre panier!';
$_['text_for']         ='%s Certificat-cadeau pour %s';


// Error

$_['error_permission'] ='Avertissement: Vous n`avez pas la permission d`accéder à l`API!';
$_['error_voucher']    ='Avertissement: Le bon cadeau est non valide ou le solde a été utilisé!';
$_['error_to_name']    ='Le nom du destinataire doit être compris entre 1 et 64 caractères!';
$_['error_from_name']  ='Votre nom doit être compris entre 1 et 64 caractères!';
$_['error_email']      ='L`adresse e-mail ne semble pas être valide!';
$_['error_theme']      ='Vous devez sélectionner un thème!';
$_['error_amount']     ='Le montant doit être compris entre %s et %s!';
