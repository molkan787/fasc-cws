<?php

// Text

$_['text_success']     ='Succès: Votre devise a été modifiée!';


// Error

$_['error_permission'] ='Avertissement: Vous n`avez pas la permission d`accéder à l`API!';
$_['error_currency']   ='Attention: le code de devise n`est pas valide!';