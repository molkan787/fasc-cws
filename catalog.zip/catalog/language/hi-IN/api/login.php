<?php

// Text

$_['text_success'] ='Succès: la session API a débuté avec succès!';


// Error

$_['error_key']  ='Avertissement: clé d`API incorrecte!';
$_['error_ip']   ='Avertissement: Votre IP %s n`est pas autorisé à accéder à cette API!';
