<?php
include_once 'utils.php';
include_once 'config.php';
include_once 'access.php';
//include_once 'store.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
