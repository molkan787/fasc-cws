<?php

$fasc_wb_url = 'http://fasc.local/';