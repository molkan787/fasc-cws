<?php
// Heading
$_['heading_title'] = 'Verify your Phone number';

// Text
$_['text_account']  = 'Account';
$_['text_verification']  = 'Verification';
$_['text_verification_code']  = 'Verification code';
$_['text_verify']  = 'Verify';
$_['text_invalid_code']  = 'Invalid verification code';
$_['text_message']  = 'We have sent a verification code to <a>%s</a>, Please type it in the box below.';